# Aplikasi Pengingat Jadwal Vaksinasi

Jalankan dengan:
```bash
pip install -r requirements.txt
python app.py
```